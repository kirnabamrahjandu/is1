//
//  ViewController.swift
//  SecondClass
//
//  Created by Mervat Mustafa on 2020-11-10.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        prodNames.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return prodNames[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        let prodPrice = findName(name: prodNames[row])
        price.text = String(prodPrice)
        img.image = UIImage(named: prodNames[row])
        
    }

    @IBOutlet weak var drop: UIPickerView!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var qtyValue: UITextField!
    @IBOutlet weak var msg: UITextField!
    @IBOutlet weak var amount: UITextField!
    @IBOutlet weak var delivery: UISwitch!
    @IBOutlet weak var qty: UISlider!
    @IBOutlet weak var price: UITextField!
    @IBOutlet weak var name: UITextField!
    var total = 0.0
    let products = ["Sanitizer":7.5,"Mask":1.0,"Gloves":3.5,"Face shield":9.5,"Soap":2.5,"Hair cap":8.0]
    let prodNames = ["Sanitizer","Mask","Gloves","Face shield","Soap","Hair cap"]
    override func viewDidLoad() {
        super.viewDidLoad()
        drop.dataSource = self
        drop.delegate = self
        
        // Do any additional setup after loading the view.
    }


    @IBAction func getQty(_ sender: Any) {
      //  let value = qty.value * 10
        
        qtyValue.text = String(qty.value.rounded())
    }
    @IBAction func findName(_ sender: Any, forEvent event: UIEvent) {
        price.text = ""
        img.image = UIImage(named: "")
        if name.text != "" {
            msg.text = ""
            let prd = findName(name: name.text!)
            if prd > 0 {
                msg.text = ""
                price.text = String(prd)
                img.image = UIImage(named: name.text!)
                
            }
            else {
                msg.text = "Sorry the product is not available"
            }
        }
        else {
            msg.text = "Please enter a product name"
        }
    }
    @IBAction func okbtn(_ sender: Any) {
       //checking if the customer wants delivery and add the delivery charge
        //suppose the store adds 10% charge for the delivery if the total amount less than 50$
        if delivery.isOn {
            if total < 150 {
                total = total * 1.1
            }
        }
        amount.text = String(total.rounded())
        total = 0
        
    }
    //this function finds and returns the price of the given product name
    @IBAction func add(_ sender: Any) {
        //finding the total price of a product by multipling the product price by the quanitity
        var am = Double(price.text!)! * Double(qtyValue.text!)!
        am = am * 1.13 //adding the tax
        total = total + am //adding to the total of all products
        amount.text = String(total.rounded())
    }
    func findName(name:String) ->Double
    {
        for prod in products.keys{
            if prod == name {
                return products[prod]!
            }
        }
        return 0.0
    }
    
    
}

